import { Server } from 'socket.io';
import { createServer } from 'http';

const PORT = 3003;

const httpServer = createServer();
const io = new Server(httpServer, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

// Store connected clients per project
const projectRooms = new Map<string, Set<string>>();

io.on('connection', (socket) => {
  console.log(`[WS] Client connected: ${socket.id}`);

  // Join a project room
  socket.on('join-project', (projectId: string) => {
    socket.join(`project:${projectId}`);
    
    if (!projectRooms.has(projectId)) {
      projectRooms.set(projectId, new Set());
    }
    projectRooms.get(projectId)!.add(socket.id);
    
    console.log(`[WS] Client ${socket.id} joined project ${projectId}`);
    
    // Notify others in the room
    socket.to(`project:${projectId}`).emit('user-joined', {
      socketId: socket.id,
      userCount: projectRooms.get(projectId)?.size || 0,
    });
  });

  // Leave a project room
  socket.on('leave-project', (projectId: string) => {
    socket.leave(`project:${projectId}`);
    projectRooms.get(projectId)?.delete(socket.id);
    
    console.log(`[WS] Client ${socket.id} left project ${projectId}`);
  });

  // Task created
  socket.on('task-created', (data: { projectId: string; task: unknown }) => {
    socket.to(`project:${data.projectId}`).emit('task-created', data.task);
  });

  // Task updated
  socket.on('task-updated', (data: { projectId: string; task: unknown }) => {
    socket.to(`project:${data.projectId}`).emit('task-updated', data.task);
  });

  // Task deleted
  socket.on('task-deleted', (data: { projectId: string; taskId: string }) => {
    socket.to(`project:${data.projectId}`).emit('task-deleted', data.taskId);
  });

  // Task moved (drag and drop)
  socket.on('task-moved', (data: { 
    projectId: string; 
    taskId: string; 
    newStatus: string;
    task: unknown;
  }) => {
    socket.to(`project:${data.projectId}`).emit('task-moved', data);
  });

  // Agent activity
  socket.on('agent-activity', (data: { 
    projectId: string; 
    agentId: string; 
    action: string;
    taskId?: string;
  }) => {
    socket.to(`project:${data.projectId}`).emit('agent-activity', data);
  });

  // Agent status changed
  socket.on('agent-status', (data: {
    projectId: string;
    agentId: string;
    isActive: boolean;
  }) => {
    socket.to(`project:${data.projectId}`).emit('agent-status', data);
  });

  // Cursor position (for collaborative editing)
  socket.on('cursor-position', (data: {
    projectId: string;
    userId: string;
    x: number;
    y: number;
  }) => {
    socket.to(`project:${data.projectId}`).emit('cursor-position', data);
  });

  // Handle disconnect
  socket.on('disconnect', () => {
    console.log(`[WS] Client disconnected: ${socket.id}`);
    
    // Remove from all project rooms
    projectRooms.forEach((sockets, projectId) => {
      if (sockets.has(socket.id)) {
        sockets.delete(socket.id);
        socket.to(`project:${projectId}`).emit('user-left', {
          socketId: socket.id,
          userCount: sockets.size,
        });
      }
    });
  });
});

httpServer.listen(PORT, () => {
  console.log(`[WS] Board WebSocket server running on port ${PORT}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('[WS] Shutting down...');
  io.close(() => {
    httpServer.close(() => {
      process.exit(0);
    });
  });
});
