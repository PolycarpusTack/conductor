'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import {
  Bot,
  Plus,
  ArrowRight,
  Menu,
  X,
  Settings,
  Trash2,
  GripVertical,
  UserPlus,
  Eye,
  Search,
  Pencil,
  Sparkles,
  Copy,
  Check,
  Key,
  Activity,
  FolderPlus,
  RefreshCw,
  ExternalLink,
} from 'lucide-react'
import { io, Socket } from 'socket.io-client'

// Types
type TaskStatus = 'BACKLOG' | 'IN_PROGRESS' | 'REVIEW' | 'DONE'
type TaskPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT'

interface Agent {
  id: string
  name: string
  emoji: string
  color: string
  description?: string
  apiKey: string
  isActive: boolean
  lastSeen?: string | null
}

interface Task {
  id: string
  title: string
  description?: string
  status: TaskStatus
  priority: TaskPriority
  tag?: string
  notes?: string
  output?: string
  agent?: Agent | null
  order: number
  startedAt?: string | null
  completedAt?: string | null
}

interface Project {
  id: string
  name: string
  description?: string
  color: string
  apiKey: string
  agents: Agent[]
  tasks: Task[]
}

interface Activity {
  id: string
  action: string
  taskId?: string
  agentId?: string
  agent?: { name: string; emoji: string }
  details?: string
  createdAt: string
}

const statusColumns: { id: TaskStatus; label: string; color: string }[] = [
  { id: 'BACKLOG', label: 'Backlog', color: 'text-muted-foreground' },
  { id: 'IN_PROGRESS', label: 'In Progress', color: 'text-blue-400' },
  { id: 'REVIEW', label: 'Review', color: 'text-violet-400' },
  { id: 'DONE', label: 'Done', color: 'text-emerald-400' },
]

const priorityColors: Record<TaskPriority, string> = {
  LOW: 'bg-muted-foreground/30',
  MEDIUM: 'bg-amber-500',
  HIGH: 'bg-orange-500',
  URGENT: 'bg-destructive',
}

const tagColors: Record<string, string> = {
  research: 'bg-violet-500/20 text-violet-400',
  docs: 'bg-blue-500/20 text-blue-400',
  backend: 'bg-emerald-500/20 text-emerald-400',
  frontend: 'bg-pink-500/20 text-pink-400',
  devops: 'bg-orange-500/20 text-orange-400',
  copy: 'bg-amber-500/20 text-amber-400',
  design: 'bg-purple-500/20 text-purple-400',
}

export default function Home() {
  const [view, setView] = useState<'landing' | 'board'>('landing')
  const [projects, setProjects] = useState<Project[]>([])
  const [currentProject, setCurrentProject] = useState<Project | null>(null)
  const [loading, setLoading] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [taskDialogOpen, setTaskDialogOpen] = useState(false)
  const [editingTask, setEditingTask] = useState<Task | null>(null)
  const [draggedTask, setDraggedTask] = useState<Task | null>(null)
  const [projectDialogOpen, setProjectDialogOpen] = useState(false)
  const [agentDialogOpen, setAgentDialogOpen] = useState(false)
  const [editingAgent, setEditingAgent] = useState<Agent | null>(null)
  const [settingsTab, setSettingsTab] = useState<'general' | 'agents' | 'api' | 'activity'>('general')
  const [activities, setActivities] = useState<Activity[]>([])
  const [copiedKey, setCopiedKey] = useState<string | null>(null)
  
  // WebSocket
  const socketRef = useRef<Socket | null>(null)
  const [wsConnected, setWsConnected] = useState(false)
  
  // Form state for tasks
  const [taskTitle, setTaskTitle] = useState('')
  const [taskDescription, setTaskDescription] = useState('')
  const [taskStatus, setTaskStatus] = useState<TaskStatus>('BACKLOG')
  const [taskPriority, setTaskPriority] = useState<TaskPriority>('MEDIUM')
  const [taskTag, setTaskTag] = useState('')
  const [taskAgentId, setTaskAgentId] = useState<string>('')
  const [taskNotes, setTaskNotes] = useState('')
  
  // Form state for projects
  const [projectName, setProjectName] = useState('')
  const [projectDescription, setProjectDescription] = useState('')
  const [projectColor, setProjectColor] = useState('#3b82f6')
  
  // Form state for agents
  const [agentName, setAgentName] = useState('')
  const [agentEmoji, setAgentEmoji] = useState('🤖')
  const [agentColor, setAgentColor] = useState('#3b82f6')
  const [agentDescription, setAgentDescription] = useState('')

  // Initialize WebSocket
  useEffect(() => {
    if (view === 'board' && currentProject) {
      socketRef.current = io('/?XTransformPort=3003', {
        transports: ['websocket'],
      })

      socketRef.current.on('connect', () => {
        console.log('[WS] Connected')
        setWsConnected(true)
        socketRef.current?.emit('join-project', currentProject.id)
      })

      socketRef.current.on('disconnect', () => {
        console.log('[WS] Disconnected')
        setWsConnected(false)
      })

      // Real-time event handlers
      socketRef.current.on('task-created', (task: Task) => {
        setCurrentProject(prev => prev ? {
          ...prev,
          tasks: [...prev.tasks, task],
        } : null)
      })

      socketRef.current.on('task-updated', (task: Task) => {
        setCurrentProject(prev => prev ? {
          ...prev,
          tasks: prev.tasks.map(t => t.id === task.id ? task : t),
        } : null)
      })

      socketRef.current.on('task-deleted', (taskId: string) => {
        setCurrentProject(prev => prev ? {
          ...prev,
          tasks: prev.tasks.filter(t => t.id !== taskId),
        } : null)
      })

      socketRef.current.on('task-moved', (data: { taskId: string; newStatus: TaskStatus; task: Task }) => {
        setCurrentProject(prev => prev ? {
          ...prev,
          tasks: prev.tasks.map(t => t.id === data.taskId ? data.task : t),
        } : null)
      })

      socketRef.current.on('agent-status', (data: { agentId: string; isActive: boolean }) => {
        setCurrentProject(prev => prev ? {
          ...prev,
          agents: prev.agents.map(a => a.id === data.agentId ? { ...a, isActive: data.isActive } : a),
        } : null)
      })

      socketRef.current.on('agent-activity', (data: Activity) => {
        setActivities(prev => [data, ...prev].slice(0, 50))
      })

      return () => {
        socketRef.current?.disconnect()
      }
    }
  }, [view, currentProject?.id])

  // Fetch all projects
  const fetchProjects = useCallback(async () => {
    try {
      const res = await fetch('/api/projects')
      const data: Project[] = await res.json()
      setProjects(data)
      return data
    } catch (error) {
      console.error('Error fetching projects:', error)
      return []
    }
  }, [])

  // Fetch single project with full data
  const fetchProject = async (projectId: string) => {
    try {
      const res = await fetch(`/api/projects/${projectId}`)
      const project = await res.json()
      return project
    } catch (error) {
      console.error('Error fetching project:', error)
      return null
    }
  }

  // Initial data load
  useEffect(() => {
    if (view === 'board') {
      const init = async () => {
        setLoading(true)
        try {
          // Seed database first
          await fetch('/api/seed', { method: 'POST' })
          
          // Fetch projects
          const projectList = await fetchProjects()
          
          if (projectList.length > 0) {
            const fullProject = await fetchProject(projectList[0].id)
            setCurrentProject(fullProject)
            
            // Fetch activities
            const actRes = await fetch(`/api/activity?projectId=${fullProject.id}&limit=20`)
            const actData = await actRes.json()
            setActivities(actData)
          }
        } catch (error) {
          console.error('Init error:', error)
        } finally {
          setLoading(false)
        }
      }
      init()
    }
  }, [view, fetchProjects])

  // Switch project
  const switchProject = async (projectId: string) => {
    const project = await fetchProject(projectId)
    setCurrentProject(project)
    
    // Switch WebSocket room
    if (socketRef.current && currentProject) {
      socketRef.current.emit('leave-project', currentProject.id)
    }
    if (socketRef.current && project) {
      socketRef.current.emit('join-project', project.id)
    }
    
    // Fetch activities for new project
    const actRes = await fetch(`/api/activity?projectId=${project.id}&limit=20`)
    const actData = await actRes.json()
    setActivities(actData)
  }

  // Create project
  const handleCreateProject = async () => {
    if (!projectName.trim()) return
    
    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: projectName,
          description: projectDescription,
          color: projectColor,
        }),
      })
      
      const newProject = await res.json()
      setProjects(prev => [...prev, newProject])
      setCurrentProject(newProject)
      
      // Reset form
      setProjectName('')
      setProjectDescription('')
      setProjectColor('#3b82f6')
      setProjectDialogOpen(false)
      
      // Create default agents
      await createDefaultAgents(newProject.id)
    } catch (error) {
      console.error('Error creating project:', error)
    }
  }

  // Create default agents for a new project
  const createDefaultAgents = async (projectId: string) => {
    const defaultAgents = [
      { name: 'Coder', emoji: '🤖', color: '#3b82f6', description: 'Backend & frontend development' },
      { name: 'Research', emoji: '🔍', color: '#8b5cf6', description: 'Research & analysis' },
      { name: 'Writer', emoji: '✏️', color: '#f59e0b', description: 'Content & documentation' },
      { name: 'QA', emoji: '🧪', color: '#10b981', description: 'Testing & quality assurance' },
    ]
    
    for (const agent of defaultAgents) {
      await fetch('/api/agents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...agent, projectId }),
      })
    }
    
    // Refresh project data
    const updated = await fetchProject(projectId)
    setCurrentProject(updated)
  }

  // Create/Update task
  const handleSaveTask = async () => {
    if (!taskTitle.trim() || !currentProject) return
    
    try {
      if (editingTask) {
        // Update existing task
        const res = await fetch(`/api/tasks/${editingTask.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: taskTitle,
            description: taskDescription,
            status: taskStatus,
            priority: taskPriority,
            tag: taskTag || undefined,
            agentId: taskAgentId || null,
            notes: taskNotes || undefined,
          }),
        })
        
        const updatedTask = await res.json()
        
        setCurrentProject(prev => prev ? {
          ...prev,
          tasks: prev.tasks.map(t => t.id === updatedTask.id ? updatedTask : t),
        } : null)
        
        // Broadcast via WebSocket
        socketRef.current?.emit('task-updated', {
          projectId: currentProject.id,
          task: updatedTask,
        })
      } else {
        // Create new task
        const res = await fetch('/api/tasks', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: taskTitle,
            description: taskDescription,
            status: taskStatus,
            priority: taskPriority,
            tag: taskTag || undefined,
            agentId: taskAgentId || undefined,
            notes: taskNotes || undefined,
            projectId: currentProject.id,
          }),
        })
        
        const newTask = await res.json()
        
        setCurrentProject(prev => prev ? {
          ...prev,
          tasks: [...prev.tasks, newTask],
        } : null)
        
        // Broadcast via WebSocket
        socketRef.current?.emit('task-created', {
          projectId: currentProject.id,
          task: newTask,
        })
      }
      
      resetTaskForm()
      setTaskDialogOpen(false)
    } catch (error) {
      console.error('Error saving task:', error)
    }
  }

  // Delete task
  const handleDeleteTask = async (taskId: string) => {
    try {
      await fetch(`/api/tasks/${taskId}`, { method: 'DELETE' })
      
      setCurrentProject(prev => prev ? {
        ...prev,
        tasks: prev.tasks.filter(t => t.id !== taskId),
      } : null)
      
      // Broadcast via WebSocket
      socketRef.current?.emit('task-deleted', {
        projectId: currentProject?.id,
        taskId,
      })
    } catch (error) {
      console.error('Error deleting task:', error)
    }
  }

  // Create/Update agent
  const handleSaveAgent = async () => {
    if (!agentName.trim() || !currentProject) return
    
    try {
      if (editingAgent) {
        const res = await fetch(`/api/agents/${editingAgent.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: agentName,
            emoji: agentEmoji,
            color: agentColor,
            description: agentDescription,
          }),
        })
        
        const updatedAgent = await res.json()
        
        setCurrentProject(prev => prev ? {
          ...prev,
          agents: prev.agents.map(a => a.id === updatedAgent.id ? updatedAgent : a),
        } : null)
      } else {
        const res = await fetch('/api/agents', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: agentName,
            emoji: agentEmoji,
            color: agentColor,
            description: agentDescription,
            projectId: currentProject.id,
          }),
        })
        
        const newAgent = await res.json()
        
        setCurrentProject(prev => prev ? {
          ...prev,
          agents: [...prev.agents, newAgent],
        } : null)
      }
      
      resetAgentForm()
      setAgentDialogOpen(false)
    } catch (error) {
      console.error('Error saving agent:', error)
    }
  }

  // Delete agent
  const handleDeleteAgent = async (agentId: string) => {
    try {
      await fetch(`/api/agents/${agentId}`, { method: 'DELETE' })
      
      setCurrentProject(prev => prev ? {
        ...prev,
        agents: prev.agents.filter(a => a.id !== agentId),
      } : null)
    } catch (error) {
      console.error('Error deleting agent:', error)
    }
  }

  // Drag and drop handlers
  const handleDragStart = (task: Task) => {
    setDraggedTask(task)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
  }

  const handleDrop = async (status: TaskStatus) => {
    if (!draggedTask || draggedTask.status === status) {
      setDraggedTask(null)
      return
    }
    
    try {
      const res = await fetch(`/api/tasks/${draggedTask.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      })
      
      const updatedTask = await res.json()
      
      setCurrentProject(prev => prev ? {
        ...prev,
        tasks: prev.tasks.map(t => t.id === updatedTask.id ? updatedTask : t),
      } : null)
      
      // Broadcast via WebSocket
      socketRef.current?.emit('task-moved', {
        projectId: currentProject?.id,
        taskId: draggedTask.id,
        newStatus: status,
        task: updatedTask,
      })
    } catch (error) {
      console.error('Error updating task status:', error)
    } finally {
      setDraggedTask(null)
    }
  }

  // Form helpers
  const openEditTaskDialog = (task: Task) => {
    setEditingTask(task)
    setTaskTitle(task.title)
    setTaskDescription(task.description || '')
    setTaskStatus(task.status)
    setTaskPriority(task.priority)
    setTaskTag(task.tag || '')
    setTaskAgentId(task.agent?.id || '')
    setTaskNotes(task.notes || '')
    setTaskDialogOpen(true)
  }

  const openNewTaskDialog = (status: TaskStatus = 'BACKLOG') => {
    resetTaskForm()
    setTaskStatus(status)
    setTaskDialogOpen(true)
  }

  const resetTaskForm = () => {
    setTaskTitle('')
    setTaskDescription('')
    setTaskStatus('BACKLOG')
    setTaskPriority('MEDIUM')
    setTaskTag('')
    setTaskAgentId('')
    setTaskNotes('')
    setEditingTask(null)
  }

  const openEditAgentDialog = (agent: Agent) => {
    setEditingAgent(agent)
    setAgentName(agent.name)
    setAgentEmoji(agent.emoji)
    setAgentColor(agent.color)
    setAgentDescription(agent.description || '')
    setAgentDialogOpen(true)
  }

  const resetAgentForm = () => {
    setAgentName('')
    setAgentEmoji('🤖')
    setAgentColor('#3b82f6')
    setAgentDescription('')
    setEditingAgent(null)
  }

  // Copy to clipboard
  const copyToClipboard = async (text: string, key: string) => {
    await navigator.clipboard.writeText(text)
    setCopiedKey(key)
    setTimeout(() => setCopiedKey(null), 2000)
  }

  // Get tasks by status
  const getTasksByStatus = (status: TaskStatus) => {
    return currentProject?.tasks.filter(t => t.status === status).sort((a, b) => a.order - b.order) || []
  }

  // Format time ago
  const timeAgo = (date: string) => {
    const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000)
    if (seconds < 60) return 'just now'
    const minutes = Math.floor(seconds / 60)
    if (minutes < 60) return `${minutes}m ago`
    const hours = Math.floor(minutes / 60)
    if (hours < 24) return `${hours}h ago`
    const days = Math.floor(hours / 24)
    return `${days}d ago`
  }

  // ===================== LANDING PAGE =====================
  if (view === 'landing') {
    return (
      <div className="min-h-screen bg-background dark">
        {/* Header */}
        <header className="fixed top-0 left-0 right-0 z-50 bg-transparent">
          <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-6">
            <a className="flex items-center gap-2" href="#">
              <div className="flex h-6 w-6 items-center justify-center rounded-md bg-foreground">
                <Bot className="h-3.5 w-3.5 text-background" />
              </div>
              <span className="text-sm font-semibold tracking-tight">AgentBoard</span>
            </a>
            <nav className="hidden items-center gap-8 md:flex">
              <a href="#features" className="text-[13px] text-muted-foreground/60 transition-colors hover:text-foreground">
                Features
              </a>
              <a href="#api" className="text-[13px] text-muted-foreground/60 transition-colors hover:text-foreground">
                API
              </a>
              <a href="#how-it-works" className="text-[13px] text-muted-foreground/60 transition-colors hover:text-foreground">
                How it works
              </a>
            </nav>
            <div className="hidden items-center gap-4 md:flex">
              <Button
                variant="ghost"
                className="text-[13px] text-muted-foreground/60 hover:text-foreground"
                onClick={() => setView('board')}
              >
                Sign in
              </Button>
              <Button
                className="rounded-lg bg-foreground px-3.5 py-1.5 text-[13px] font-medium text-background hover:bg-foreground/90"
                onClick={() => setView('board')}
              >
                Get Started
              </Button>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
          </div>
        </header>

        {/* Mobile menu */}
        {sidebarOpen && (
          <div className="fixed inset-0 z-40 bg-background/95 backdrop-blur-sm md:hidden pt-14">
            <nav className="flex flex-col items-center gap-6 p-8">
              <a href="#features" className="text-lg text-muted-foreground" onClick={() => setSidebarOpen(false)}>
                Features
              </a>
              <a href="#api" className="text-lg text-muted-foreground" onClick={() => setSidebarOpen(false)}>
                API
              </a>
              <Button
                className="w-full rounded-lg bg-foreground text-background"
                onClick={() => { setSidebarOpen(false); setView('board') }}
              >
                Get Started
              </Button>
            </nav>
          </div>
        )}

        <main>
          {/* Hero Section */}
          <section className="relative overflow-hidden pt-28 pb-16 md:pt-36 md:pb-24">
            <div className="pointer-events-none absolute inset-0 opacity-[0.015]" style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='1'/%3E%3C/svg%3E")`
            }} />
            <div className="pointer-events-none absolute right-0 top-16 h-[500px] w-[500px] rounded-full bg-blue-500/[0.03] blur-[100px]" />
            <div className="pointer-events-none absolute left-1/4 top-48 h-[300px] w-[300px] rounded-full bg-violet-500/[0.02] blur-[80px]" />
            
            <div className="relative mx-auto max-w-6xl px-6">
              <div className="text-center max-w-3xl mx-auto">
                <h1 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-[3.5rem] lg:leading-[1.1]">
                  Manage agents like a team.
                  <br />
                  <span className="text-muted-foreground">Real APIs. Real-time. Real workflows.</span>
                </h1>
                <p className="mt-6 max-w-2xl mx-auto text-base leading-relaxed text-muted-foreground sm:text-[17px]">
                  AgentBoard gives your AI agents a shared backlog with real HTTP APIs, WebSocket updates, and CLI tools. 
                  Connect your agents, track progress, and ship faster.
                </p>
                <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row sm:gap-4">
                  <Button
                    className="group inline-flex items-center gap-2 rounded-lg bg-foreground px-5 py-2.5 text-sm font-medium text-background"
                    onClick={() => setView('board')}
                  >
                    Launch Board
                    <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                  </Button>
                  <a
                    href="#api"
                    className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    View API docs
                    <span className="text-[10px]">↓</span>
                  </a>
                </div>
              </div>
            </div>
          </section>

          {/* API Section */}
          <section id="api" className="relative py-24 md:py-32">
            <div className="mx-auto max-w-6xl px-6">
              <div className="text-center mb-16">
                <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Agent HTTP API</h2>
                <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
                  Connect your AI agents via simple HTTP endpoints. No complex setup required.
                </p>
              </div>
              
              <div className="grid gap-8 md:grid-cols-2">
                {/* CLI API */}
                <div className="rounded-xl border border-border/30 bg-card p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <span className="text-xl">⚡</span> CLI-Style API
                  </h3>
                  <div className="space-y-4">
                    <div className="rounded-lg bg-muted/30 p-3 font-mono text-xs">
                      <div className="text-muted-foreground"># Get next task</div>
                      <div>GET /api/cli?api_key=<span className="text-emerald-400">YOUR_KEY</span></div>
                    </div>
                    <div className="rounded-lg bg-muted/30 p-3 font-mono text-xs">
                      <div className="text-muted-foreground"># Claim and start task</div>
                      <div>POST /api/cli</div>
                      <div className="text-blue-400">{"{"} "api_key": "...", "action": "claim", "task_id": "..." {"}"}</div>
                    </div>
                    <div className="rounded-lg bg-muted/30 p-3 font-mono text-xs">
                      <div className="text-muted-foreground"># Complete task</div>
                      <div>POST /api/cli</div>
                      <div className="text-blue-400">{"{"} "api_key": "...", "action": "done", "task_id": "...", "output": "shipped" {"}"}</div>
                    </div>
                  </div>
                </div>
                
                {/* REST API */}
                <div className="rounded-xl border border-border/30 bg-card p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <span className="text-xl">🔗</span> REST API
                  </h3>
                  <div className="space-y-4">
                    <div className="rounded-lg bg-muted/30 p-3 font-mono text-xs">
                      <div className="text-muted-foreground"># Get agent&apos;s tasks</div>
                      <div>GET /api/agent/tasks?api_key=<span className="text-emerald-400">AGENT_KEY</span></div>
                    </div>
                    <div className="rounded-lg bg-muted/30 p-3 font-mono text-xs">
                      <div className="text-muted-foreground"># Update task with action</div>
                      <div>PUT /api/agent/tasks/:id</div>
                      <div className="text-blue-400">{"{"} "api_key": "...", "action": "complete", "output": "..." {"}"}</div>
                    </div>
                    <div className="rounded-lg bg-muted/30 p-3 font-mono text-xs">
                      <div className="text-muted-foreground"># Available actions</div>
                      <div className="text-foreground/70">claim, start, progress, complete, review, block</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Features Section */}
          <section id="features" className="relative py-24 md:py-32">
            <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
            
            <div className="mx-auto max-w-6xl px-6">
              <p className="mb-16 text-xs uppercase tracking-[0.2em] text-muted-foreground/40">Why AgentBoard</p>
              
              <div className="grid gap-8 md:grid-cols-3">
                <div className="rounded-xl border border-border/30 bg-card p-6">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-blue-500/10">
                    <Key className="h-6 w-6 text-blue-400" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Real Agent APIs</h3>
                  <p className="text-sm text-muted-foreground">
                    Every agent gets an API key. Connect via HTTP, CLI, or integrate directly into your agent&apos;s workflow.
                  </p>
                </div>
                
                <div className="rounded-xl border border-border/30 bg-card p-6">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-violet-500/10">
                    <RefreshCw className="h-6 w-6 text-violet-400" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Real-time Updates</h3>
                  <p className="text-sm text-muted-foreground">
                    WebSocket-powered board updates. See agent activity and task changes in real-time.
                  </p>
                </div>
                
                <div className="rounded-xl border border-border/30 bg-card p-6">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-emerald-500/10">
                    <Activity className="h-6 w-6 text-emerald-400" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Activity Tracking</h3>
                  <p className="text-sm text-muted-foreground">
                    Full audit trail of agent actions. Know exactly what each agent did and when.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* CTA */}
          <section className="relative py-24 md:py-32">
            <div className="mx-auto max-w-6xl px-6 text-center">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
                Ready to orchestrate your AI agents?
              </h2>
              <Button
                className="mt-8 group inline-flex items-center gap-2 rounded-lg bg-foreground px-6 py-3 text-sm font-medium text-background"
                onClick={() => setView('board')}
              >
                Launch AgentBoard
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </Button>
            </div>
          </section>
        </main>

        {/* Footer */}
        <footer className="border-t border-border/20 py-8">
          <div className="mx-auto max-w-6xl px-6 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-5 w-5 items-center justify-center rounded bg-foreground">
                <Bot className="h-3 w-3 text-background" />
              </div>
              <span className="text-xs text-muted-foreground">AgentBoard</span>
            </div>
            <p className="text-xs text-muted-foreground/40">
              Task management for the age of agents
            </p>
          </div>
        </footer>
      </div>
    )
  }

  // ===================== BOARD VIEW =====================
  return (
    <div className="min-h-screen bg-background dark">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 border-b border-border/20 bg-background/80 backdrop-blur-sm">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              <Menu className="h-4 w-4" />
            </Button>
            <a className="flex items-center gap-2 cursor-pointer" onClick={() => setView('landing')}>
              <div className="flex h-6 w-6 items-center justify-center rounded-md bg-foreground">
                <Bot className="h-3.5 w-3.5 text-background" />
              </div>
              <span className="text-sm font-semibold tracking-tight">AgentBoard</span>
            </a>
            
            {/* WebSocket status */}
            <div className={`hidden sm:flex items-center gap-1.5 px-2 py-1 rounded-full text-[10px] ${wsConnected ? 'bg-emerald-500/10 text-emerald-400' : 'bg-muted text-muted-foreground'}`}>
              <div className={`h-1.5 w-1.5 rounded-full ${wsConnected ? 'bg-emerald-400 animate-pulse' : 'bg-muted-foreground/50'}`} />
              {wsConnected ? 'Live' : 'Offline'}
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {/* Project selector */}
            {projects.length > 1 && (
              <Select value={currentProject?.id} onValueChange={switchProject}>
                <SelectTrigger className="w-[160px] h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {projects.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-2 rounded-sm" style={{ backgroundColor: p.color }} />
                        {p.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            
            {/* Agent status indicators */}
            {currentProject?.agents && (
              <div className="hidden sm:flex items-center gap-1">
                {currentProject.agents.map((agent) => (
                  <div key={agent.id} className="relative group">
                    <Avatar className="h-7 w-7 border border-border/30 bg-surface">
                      <AvatarFallback className="text-xs bg-transparent">
                        {agent.emoji}
                      </AvatarFallback>
                    </Avatar>
                    {agent.isActive && (
                      <div className="absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full bg-emerald-500 ring-1 ring-background">
                        <div className="absolute inset-0 animate-ping rounded-full bg-emerald-500/50" />
                      </div>
                    )}
                    <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-popover text-[10px] px-2 py-0.5 rounded whitespace-nowrap z-10">
                      {agent.name} {agent.isActive ? '(active)' : ''}
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* New Project button */}
            <Button
              variant="outline"
              size="sm"
              className="h-7 text-[11px] gap-1"
              onClick={() => setProjectDialogOpen(true)}
            >
              <FolderPlus className="h-3 w-3" />
              <span className="hidden sm:inline">New Project</span>
            </Button>
            
            {/* Settings */}
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setSettingsTab('general')}
            >
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Mobile Sidebar */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-background/95 backdrop-blur-sm md:hidden pt-14">
          <div className="p-4">
            <div className="mb-4">
              <h3 className="text-xs font-medium uppercase tracking-wider text-muted-foreground/50 mb-2">Projects</h3>
              <div className="space-y-1">
                {projects.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => { switchProject(p.id); setSidebarOpen(false) }}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm ${p.id === currentProject?.id ? 'bg-surface/60' : 'hover:bg-surface/40'}`}
                  >
                    {p.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="pt-14 flex">
        {/* Desktop Sidebar */}
        <aside className="hidden md:block w-56 shrink-0 border-r border-border/15 p-3 min-h-[calc(100vh-3.5rem)]">
          <div className="mb-4 flex items-center gap-1.5">
            <div className="h-3 w-3 rounded bg-primary/60" />
            <span className="text-[10px] font-medium text-foreground/50">AgentBoard</span>
          </div>
          
          <div className="mb-4">
            <h3 className="text-[9px] font-medium uppercase tracking-wider text-muted-foreground/40 mb-2 px-2">Projects</h3>
            <div className="space-y-0.5">
              {projects.map((p) => (
                <button
                  key={p.id}
                  onClick={() => switchProject(p.id)}
                  className={`w-full text-left rounded-md px-2 py-1.5 text-[11px] font-medium flex items-center gap-2 ${p.id === currentProject?.id ? 'bg-surface/60 text-foreground/70' : 'text-muted-foreground/50 hover:bg-surface/40'}`}
                >
                  <div className="h-2 w-2 rounded-sm" style={{ backgroundColor: p.color }} />
                  {p.name}
                </button>
              ))}
            </div>
          </div>
          
          <Separator className="my-4" />
          
          <div className="mt-4">
            <h3 className="text-[9px] font-medium uppercase tracking-wider text-muted-foreground/40 mb-2 px-2">Agents</h3>
            <div className="space-y-0.5">
              {currentProject?.agents.map((agent) => {
                const taskCount = currentProject.tasks.filter(t => t.agent?.id === agent.id && t.status !== 'DONE').length
                return (
                  <div key={agent.id} className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-surface/40 transition-colors cursor-pointer">
                    <span className="text-sm">{agent.emoji}</span>
                    <span className="text-[11px] text-foreground/70 flex-1">{agent.name}</span>
                    {agent.isActive && (
                      <div className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                    )}
                    {taskCount > 0 && (
                      <span className="text-[9px] text-muted-foreground/50">{taskCount}</span>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
          
          <Separator className="my-4" />
          
          <div className="mt-4">
            <h3 className="text-[9px] font-medium uppercase tracking-wider text-muted-foreground/40 mb-2 px-2">Tags</h3>
            <div className="flex flex-wrap gap-1 px-2">
              {Array.from(new Set(currentProject?.tasks.map(t => t.tag).filter(Boolean))).map((tag) => (
                <Badge key={tag} variant="secondary" className="text-[9px] px-1.5 py-0">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
        </aside>

        {/* Board */}
        <div className="flex-1 overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center h-[calc(100vh-3.5rem)]">
              <div className="flex flex-col items-center gap-3">
                <Sparkles className="h-8 w-8 text-muted-foreground/30 animate-pulse" />
                <span className="text-sm text-muted-foreground">Loading board...</span>
              </div>
            </div>
          ) : (
            <ScrollArea className="h-[calc(100vh-3.5rem)] custom-scrollbar">
              <div className="p-4 min-w-[800px]">
                <div className="grid grid-cols-4 gap-4">
                  {statusColumns.map((column) => {
                    const tasks = getTasksByStatus(column.id)
                    return (
                      <div
                        key={column.id}
                        className="min-w-0"
                        onDragOver={handleDragOver}
                        onDrop={() => handleDrop(column.id)}
                      >
                        <div className="mb-3 flex items-center justify-between px-1">
                          <div className="flex items-center gap-2">
                            <span className={`text-[11px] font-medium uppercase tracking-wider ${column.color}`}>
                              {column.label}
                            </span>
                            <span className="text-[10px] text-muted-foreground/30">{tasks.length}</span>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-5 w-5 opacity-0 hover:opacity-100 group-hover:opacity-50 transition-opacity"
                            onClick={() => openNewTaskDialog(column.id)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                        
                        <div className="flex flex-col gap-2">
                          {tasks.map((task) => (
                            <div
                              key={task.id}
                              draggable
                              onDragStart={() => handleDragStart(task)}
                              className="group rounded-lg border border-border/40 bg-card p-3 cursor-grab active:cursor-grabbing hover:border-border/60 transition-colors"
                            >
                              <div className="flex items-start gap-2">
                                <GripVertical className="h-3.5 w-3.5 text-muted-foreground/20 mt-0.5 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" />
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-start justify-between gap-2">
                                    <div className="flex items-start gap-1.5">
                                      <span className={`mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full ${priorityColors[task.priority]}`} />
                                      <span className="text-[13px] font-medium leading-tight text-foreground/90">{task.title}</span>
                                    </div>
                                    {task.agent && (
                                      <span className="text-[11px] shrink-0" title={task.agent.name}>
                                        {task.agent.emoji}
                                      </span>
                                    )}
                                  </div>
                                  
                                  {task.notes && (
                                    <div className="mt-2 rounded-md bg-surface/60 px-2 py-1.5">
                                      <p className="text-[10px] leading-snug text-muted-foreground line-clamp-2">{task.notes}</p>
                                    </div>
                                  )}
                                  
                                  <div className="mt-2 flex items-center justify-between">
                                    {task.tag ? (
                                      <span className={`rounded px-1.5 py-0.5 text-[9px] ${tagColors[task.tag] || 'bg-surface text-muted-foreground'}`}>
                                        {task.tag}
                                      </span>
                                    ) : (
                                      <div />
                                    )}
                                    
                                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-5 w-5"
                                        onClick={() => openEditTaskDialog(task)}
                                      >
                                        <Pencil className="h-2.5 w-2.5 text-muted-foreground" />
                                      </Button>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-5 w-5"
                                        onClick={() => handleDeleteTask(task.id)}
                                      >
                                        <Trash2 className="h-2.5 w-2.5 text-muted-foreground hover:text-destructive" />
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                          
                          {/* Add task button */}
                          <button
                            onClick={() => openNewTaskDialog(column.id)}
                            className="flex items-center gap-2 rounded-lg border border-dashed border-border/30 p-2 text-[11px] text-muted-foreground/50 hover:border-border/50 hover:text-muted-foreground/70 transition-colors"
                          >
                            <Plus className="h-3 w-3" />
                            Add task
                          </button>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </ScrollArea>
          )}
        </div>
      </main>

      {/* Task Dialog */}
      <Dialog open={taskDialogOpen} onOpenChange={(open) => { setTaskDialogOpen(open); if (!open) resetTaskForm() }}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{editingTask ? 'Edit Task' : 'Create New Task'}</DialogTitle>
            <DialogDescription>
              {editingTask ? 'Update the task details below.' : 'Add a new task to your board.'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label className="text-sm font-medium">Title</label>
              <Input
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                placeholder="Enter task title..."
              />
            </div>
            
            <div className="grid gap-2">
              <label className="text-sm font-medium">Description</label>
              <Textarea
                value={taskDescription}
                onChange={(e) => setTaskDescription(e.target.value)}
                placeholder="Enter task description..."
                rows={2}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <label className="text-sm font-medium">Status</label>
                <Select value={taskStatus} onValueChange={(v) => setTaskStatus(v as TaskStatus)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {statusColumns.map((col) => (
                      <SelectItem key={col.id} value={col.id}>{col.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <label className="text-sm font-medium">Priority</label>
                <Select value={taskPriority} onValueChange={(v) => setTaskPriority(v as TaskPriority)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="LOW">Low</SelectItem>
                    <SelectItem value="MEDIUM">Medium</SelectItem>
                    <SelectItem value="HIGH">High</SelectItem>
                    <SelectItem value="URGENT">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <label className="text-sm font-medium">Tag</label>
                <Select value={taskTag} onValueChange={setTaskTag}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select tag..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="research">research</SelectItem>
                    <SelectItem value="docs">docs</SelectItem>
                    <SelectItem value="backend">backend</SelectItem>
                    <SelectItem value="frontend">frontend</SelectItem>
                    <SelectItem value="devops">devops</SelectItem>
                    <SelectItem value="copy">copy</SelectItem>
                    <SelectItem value="design">design</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <label className="text-sm font-medium">Agent</label>
                <Select value={taskAgentId} onValueChange={setTaskAgentId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Assign agent..." />
                  </SelectTrigger>
                  <SelectContent>
                    {currentProject?.agents.map((agent) => (
                      <SelectItem key={agent.id} value={agent.id}>
                        {agent.emoji} {agent.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid gap-2">
              <label className="text-sm font-medium">Notes</label>
              <Textarea
                value={taskNotes}
                onChange={(e) => setTaskNotes(e.target.value)}
                placeholder="Progress notes, status updates..."
                rows={2}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => { setTaskDialogOpen(false); resetTaskForm() }}>
              Cancel
            </Button>
            <Button onClick={handleSaveTask}>
              {editingTask ? 'Save Changes' : 'Create Task'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Project Dialog */}
      <Dialog open={projectDialogOpen} onOpenChange={setProjectDialogOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>Create New Project</DialogTitle>
            <DialogDescription>
              Create a new project to organize your agents and tasks.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label className="text-sm font-medium">Project Name</label>
              <Input
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                placeholder="My Project"
              />
            </div>
            
            <div className="grid gap-2">
              <label className="text-sm font-medium">Description</label>
              <Textarea
                value={projectDescription}
                onChange={(e) => setProjectDescription(e.target.value)}
                placeholder="Brief description..."
                rows={2}
              />
            </div>
            
            <div className="grid gap-2">
              <label className="text-sm font-medium">Color</label>
              <div className="flex gap-2">
                {['#3b82f6', '#8b5cf6', '#f59e0b', '#10b981', '#ef4444', '#ec4899'].map((color) => (
                  <button
                    key={color}
                    onClick={() => setProjectColor(color)}
                    className={`h-6 w-6 rounded-full ring-2 ring-offset-2 ring-offset-background ${projectColor === color ? 'ring-foreground' : 'ring-transparent'}`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setProjectDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateProject}>Create Project</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Settings Dialog */}
      <Dialog open={settingsTab !== null} onOpenChange={(open) => !open && setSettingsTab(null as never)}>
        <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle>Project Settings</DialogTitle>
          </DialogHeader>
          
          <Tabs value={settingsTab} onValueChange={(v) => setSettingsTab(v as typeof settingsTab)}>
            <TabsList className="grid grid-cols-4 w-full">
              <TabsTrigger value="general" className="text-xs">General</TabsTrigger>
              <TabsTrigger value="agents" className="text-xs">Agents</TabsTrigger>
              <TabsTrigger value="api" className="text-xs">API Keys</TabsTrigger>
              <TabsTrigger value="activity" className="text-xs">Activity</TabsTrigger>
            </TabsList>
            
            <div className="mt-4 overflow-y-auto max-h-[50vh]">
              {/* General Tab */}
              <TabsContent value="general" className="mt-0">
                <div className="space-y-4">
                  <div className="grid gap-2">
                    <label className="text-sm font-medium">Project Name</label>
                    <Input value={currentProject?.name || ''} readOnly />
                  </div>
                  <div className="grid gap-2">
                    <label className="text-sm font-medium">Description</label>
                    <Textarea value={currentProject?.description || ''} readOnly rows={2} />
                  </div>
                  <div className="grid gap-2">
                    <label className="text-sm font-medium">Tasks Summary</label>
                    <div className="grid grid-cols-4 gap-2 text-center">
                      {statusColumns.map((col) => (
                        <div key={col.id} className="rounded-lg bg-muted/30 p-2">
                          <div className="text-lg font-bold">{getTasksByStatus(col.id).length}</div>
                          <div className="text-[10px] text-muted-foreground">{col.label}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              {/* Agents Tab */}
              <TabsContent value="agents" className="mt-0">
                <div className="space-y-3">
                  {currentProject?.agents.map((agent) => (
                    <div key={agent.id} className="flex items-center justify-between p-3 rounded-lg border border-border/30">
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{agent.emoji}</span>
                        <div>
                          <div className="text-sm font-medium flex items-center gap-2">
                            {agent.name}
                            {agent.isActive && (
                              <Badge variant="outline" className="text-[9px] bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                                Active
                              </Badge>
                            )}
                          </div>
                          <div className="text-xs text-muted-foreground">{agent.description}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="sm" onClick={() => openEditAgentDialog(agent)}>
                          <Pencil className="h-3 w-3" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDeleteAgent(agent.id)}>
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  
                  <Button variant="outline" className="w-full" onClick={() => { resetAgentForm(); setAgentDialogOpen(true) }}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Agent
                  </Button>
                </div>
              </TabsContent>
              
              {/* API Keys Tab */}
              <TabsContent value="api" className="mt-0">
                <div className="space-y-4">
                  <div className="rounded-lg border border-border/30 p-4">
                    <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                      <Key className="h-4 w-4" />
                      Project API Key
                    </h4>
                    <p className="text-xs text-muted-foreground mb-2">Use this key for project-level operations.</p>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 text-xs bg-muted/30 px-3 py-2 rounded font-mono">
                        {currentProject?.apiKey}
                      </code>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(currentProject?.apiKey || '', 'project')}
                      >
                        {copiedKey === 'project' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="rounded-lg border border-border/30 p-4">
                    <h4 className="text-sm font-medium mb-3">Agent API Keys</h4>
                    <p className="text-xs text-muted-foreground mb-3">Each agent has a unique API key for authentication.</p>
                    <div className="space-y-2">
                      {currentProject?.agents.map((agent) => (
                        <div key={agent.id} className="flex items-center gap-2 p-2 rounded bg-muted/20">
                          <span>{agent.emoji}</span>
                          <span className="text-xs flex-1 font-mono truncate">{agent.apiKey}</span>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0"
                            onClick={() => copyToClipboard(agent.apiKey, agent.id)}
                          >
                            {copiedKey === agent.id ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="rounded-lg border border-border/30 p-4">
                    <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                      <ExternalLink className="h-4 w-4" />
                      API Endpoints
                    </h4>
                    <div className="space-y-2 text-xs font-mono">
                      <div className="p-2 rounded bg-muted/20">
                        <div className="text-muted-foreground"># Get agent tasks</div>
                        <div>GET /api/agent/tasks?api_key=<span className="text-emerald-400">AGENT_KEY</span></div>
                      </div>
                      <div className="p-2 rounded bg-muted/20">
                        <div className="text-muted-foreground"># CLI-style interface</div>
                        <div>GET /api/cli?api_key=<span className="text-emerald-400">AGENT_KEY</span></div>
                      </div>
                      <div className="p-2 rounded bg-muted/20">
                        <div className="text-muted-foreground"># Task actions</div>
                        <div>PUT /api/agent/tasks/:id {"{"} action: "claim"|"start"|"complete" {"}"}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              {/* Activity Tab */}
              <TabsContent value="activity" className="mt-0">
                <div className="space-y-2">
                  {activities.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground text-sm">
                      No activity yet
                    </div>
                  ) : (
                    activities.map((activity) => (
                      <div key={activity.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-muted/20">
                        <span className="text-lg">{activity.agent?.emoji || '📋'}</span>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm">
                            <span className="font-medium">{activity.agent?.name || 'System'}</span>
                            <span className="text-muted-foreground ml-2">{activity.action}</span>
                          </div>
                          {activity.details && (
                            <div className="text-xs text-muted-foreground truncate">{activity.details}</div>
                          )}
                        </div>
                        <span className="text-[10px] text-muted-foreground/50">{timeAgo(activity.createdAt)}</span>
                      </div>
                    ))
                  )}
                </div>
              </TabsContent>
            </div>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Agent Dialog */}
      <Dialog open={agentDialogOpen} onOpenChange={(open) => { setAgentDialogOpen(open); if (!open) resetAgentForm() }}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>{editingAgent ? 'Edit Agent' : 'Create Agent'}</DialogTitle>
            <DialogDescription>
              {editingAgent ? 'Update agent details.' : 'Create a new AI agent for this project.'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <label className="text-sm font-medium">Name</label>
                <Input
                  value={agentName}
                  onChange={(e) => setAgentName(e.target.value)}
                  placeholder="Agent name"
                />
              </div>
              <div className="grid gap-2">
                <label className="text-sm font-medium">Emoji</label>
                <Input
                  value={agentEmoji}
                  onChange={(e) => setAgentEmoji(e.target.value)}
                  placeholder="🤖"
                  className="text-center text-xl"
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <label className="text-sm font-medium">Description</label>
              <Textarea
                value={agentDescription}
                onChange={(e) => setAgentDescription(e.target.value)}
                placeholder="What does this agent do?"
                rows={2}
              />
            </div>
            
            <div className="grid gap-2">
              <label className="text-sm font-medium">Color</label>
              <div className="flex gap-2">
                {['#3b82f6', '#8b5cf6', '#f59e0b', '#10b981', '#ef4444', '#ec4899'].map((color) => (
                  <button
                    key={color}
                    onClick={() => setAgentColor(color)}
                    className={`h-6 w-6 rounded-full ring-2 ring-offset-2 ring-offset-background ${agentColor === color ? 'ring-foreground' : 'ring-transparent'}`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setAgentDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveAgent}>
              {editingAgent ? 'Save Changes' : 'Create Agent'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
