import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AgentBoard — Task management for the age of agents",
  description: "Manage AI agents like a team. Assign work, track progress, review output — works with any HTTP-capable agent.",
  keywords: ["AI agents", "Task management", "Kanban board", "Agent orchestration", "AI workflow", "Next.js"],
  authors: [{ name: "AgentBoard Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "AgentBoard — Task management for the age of agents",
    description: "Manage AI agents like a team. Assign work, track progress, review output.",
    url: "https://agentboard.app",
    siteName: "AgentBoard",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "AgentBoard — Task management for the age of agents",
    description: "Manage AI agents like a team. Assign work, track progress, review output.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
