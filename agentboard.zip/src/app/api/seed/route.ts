import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST() {
  try {
    // Check if data already exists
    const existingProjects = await db.project.count();
    if (existingProjects > 0) {
      return NextResponse.json({ message: 'Database already seeded' });
    }
    
    // Create a default project with API key
    const project = await db.project.create({
      data: {
        name: 'API Project',
        description: 'Main development project - Demo for AgentBoard',
        color: '#3b82f6',
        apiKey: 'proj_demo_' + Math.random().toString(36).substring(2, 15),
      },
    });
    
    // Create default agents with API keys
    const coder = await db.agent.create({
      data: {
        name: 'Coder',
        emoji: '🤖',
        color: '#3b82f6',
        description: 'Backend & frontend development',
        apiKey: 'agent_coder_' + Math.random().toString(36).substring(2, 15),
        projectId: project.id,
        isActive: false,
      },
    });
    
    const research = await db.agent.create({
      data: {
        name: 'Research',
        emoji: '🔍',
        color: '#8b5cf6',
        description: 'Research & analysis',
        apiKey: 'agent_research_' + Math.random().toString(36).substring(2, 15),
        projectId: project.id,
        isActive: false,
      },
    });
    
    const writer = await db.agent.create({
      data: {
        name: 'Writer',
        emoji: '✏️',
        color: '#f59e0b',
        description: 'Content & documentation',
        apiKey: 'agent_writer_' + Math.random().toString(36).substring(2, 15),
        projectId: project.id,
        isActive: false,
      },
    });
    
    const qa = await db.agent.create({
      data: {
        name: 'QA',
        emoji: '🧪',
        color: '#10b981',
        description: 'Testing & quality assurance',
        apiKey: 'agent_qa_' + Math.random().toString(36).substring(2, 15),
        projectId: project.id,
        isActive: false,
      },
    });
    
    // Create sample tasks
    const tasks = await db.task.createMany({
      data: [
        {
          title: 'Research competitor APIs',
          description: 'Analyze top 5 competitors API design patterns',
          status: 'BACKLOG',
          priority: 'MEDIUM',
          tag: 'research',
          projectId: project.id,
          agentId: research.id,
          order: 1,
        },
        {
          title: 'Write changelog for v2.1',
          description: 'Document all changes for the upcoming release',
          status: 'BACKLOG',
          priority: 'LOW',
          tag: 'docs',
          projectId: project.id,
          agentId: writer.id,
          order: 2,
        },
        {
          title: 'Implement auth middleware',
          description: 'Add JWT authentication to API routes',
          status: 'IN_PROGRESS',
          priority: 'HIGH',
          tag: 'backend',
          projectId: project.id,
          agentId: coder.id,
          notes: 'Running tests on token refresh flow...',
          order: 1,
          startedAt: new Date(Date.now() - 3600000), // Started 1 hour ago
        },
        {
          title: 'Summarize user interviews',
          description: 'Compile insights from 12 user interviews',
          status: 'IN_PROGRESS',
          priority: 'MEDIUM',
          tag: 'research',
          projectId: project.id,
          agentId: research.id,
          notes: 'Processed 8/12 transcripts',
          order: 2,
          startedAt: new Date(Date.now() - 7200000), // Started 2 hours ago
        },
        {
          title: 'Draft onboarding emails',
          description: 'Create email sequence for new users',
          status: 'REVIEW',
          priority: 'MEDIUM',
          tag: 'copy',
          projectId: project.id,
          agentId: writer.id,
          order: 1,
          output: 'Created 5-email welcome sequence. Awaiting review.',
        },
        {
          title: 'Set up CI pipeline',
          description: 'Configure GitHub Actions for automated testing',
          status: 'DONE',
          priority: 'HIGH',
          tag: 'devops',
          projectId: project.id,
          agentId: coder.id,
          order: 1,
          completedAt: new Date(Date.now() - 86400000), // Completed yesterday
        },
        {
          title: 'Design system components',
          description: 'Create reusable UI component library',
          status: 'DONE',
          priority: 'MEDIUM',
          tag: 'frontend',
          projectId: project.id,
          agentId: coder.id,
          order: 2,
          completedAt: new Date(Date.now() - 172800000), // Completed 2 days ago
        },
        {
          title: 'API documentation',
          description: 'Write OpenAPI specs for all endpoints',
          status: 'DONE',
          priority: 'HIGH',
          tag: 'docs',
          projectId: project.id,
          agentId: writer.id,
          order: 3,
          completedAt: new Date(Date.now() - 259200000), // Completed 3 days ago
        },
      ],
    });

    // Create some activity logs
    await db.activityLog.createMany({
      data: [
        {
          action: 'started',
          taskId: null, // We don't have the IDs from createMany
          agentId: coder.id,
          projectId: project.id,
          details: 'Started working on auth middleware',
          createdAt: new Date(Date.now() - 3600000),
        },
        {
          action: 'progress',
          agentId: coder.id,
          projectId: project.id,
          details: 'Running tests on token refresh flow...',
          createdAt: new Date(Date.now() - 1800000),
        },
        {
          action: 'started',
          agentId: research.id,
          projectId: project.id,
          details: 'Started summarizing user interviews',
          createdAt: new Date(Date.now() - 7200000),
        },
        {
          action: 'completed',
          agentId: coder.id,
          projectId: project.id,
          details: 'CI pipeline configured and running',
          createdAt: new Date(Date.now() - 86400000),
        },
      ],
    });
    
    return NextResponse.json({
      success: true,
      message: 'Database seeded successfully',
      project: {
        id: project.id,
        name: project.name,
        apiKey: project.apiKey,
      },
      agents: [
        { id: coder.id, name: coder.name, apiKey: coder.apiKey },
        { id: research.id, name: research.name, apiKey: research.apiKey },
        { id: writer.id, name: writer.name, apiKey: writer.apiKey },
        { id: qa.id, name: qa.name, apiKey: qa.apiKey },
      ],
      tasksCount: tasks.count,
    });
  } catch (error) {
    console.error('Error seeding database:', error);
    return NextResponse.json({ error: 'Failed to seed database' }, { status: 500 });
  }
}
