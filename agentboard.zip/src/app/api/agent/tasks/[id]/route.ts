import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * Agent HTTP API - Task operations
 * 
 * Headers:
 * - X-Agent-Key: Agent API key
 * 
 * Operations:
 * - GET: Get task details
 * - PUT: Update task (start, add notes, complete)
 * - DELETE: Unassign from agent
 */

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const apiKey = searchParams.get('api_key') || request.headers.get('X-Agent-Key');

    if (!apiKey) {
      return NextResponse.json({ error: 'Missing API key' }, { status: 401 });
    }

    const agent = await db.agent.findUnique({ where: { apiKey } });
    if (!agent) {
      return NextResponse.json({ error: 'Invalid API key' }, { status: 401 });
    }

    const task = await db.task.findUnique({
      where: { id },
      include: {
        agent: true,
        project: { select: { name: true, color: true } },
      },
    });

    if (!task) {
      return NextResponse.json({ error: 'Task not found' }, { status: 404 });
    }

    if (task.projectId !== agent.projectId) {
      return NextResponse.json({ error: 'Task not in your project' }, { status: 403 });
    }

    return NextResponse.json(task);
  } catch (error) {
    console.error('Error fetching task:', error);
    return NextResponse.json({ error: 'Failed to fetch task' }, { status: 500 });
  }
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const apiKey = body.api_key || request.headers.get('X-Agent-Key');

    if (!apiKey) {
      return NextResponse.json({ error: 'Missing API key' }, { status: 401 });
    }

    const agent = await db.agent.findUnique({ where: { apiKey } });
    if (!agent) {
      return NextResponse.json({ error: 'Invalid API key' }, { status: 401 });
    }

    const existingTask = await db.task.findUnique({
      where: { id },
    });

    if (!existingTask) {
      return NextResponse.json({ error: 'Task not found' }, { status: 404 });
    }

    if (existingTask.projectId !== agent.projectId) {
      return NextResponse.json({ error: 'Task not in your project' }, { status: 403 });
    }

    const { action, notes, output, status } = body;

    // Handle different actions
    let updateData: Record<string, unknown> = {};
    let logAction = 'updated';
    let logDetails = '';

    switch (action) {
      case 'claim':
        // Claim an unassigned task
        if (existingTask.agentId && existingTask.agentId !== agent.id) {
          return NextResponse.json({ error: 'Task already claimed by another agent' }, { status: 409 });
        }
        updateData = {
          agentId: agent.id,
          status: 'IN_PROGRESS',
          startedAt: new Date(),
        };
        logAction = 'claimed';
        logDetails = `Claimed by ${agent.name}`;
        break;

      case 'start':
        // Start working on assigned task
        updateData = {
          status: 'IN_PROGRESS',
          startedAt: new Date(),
        };
        logAction = 'started';
        logDetails = `Started by ${agent.name}`;
        break;

      case 'progress':
        // Update progress notes
        updateData = {
          notes: notes || existingTask.notes,
        };
        logAction = 'progress';
        logDetails = notes || '';
        break;

      case 'complete':
        // Mark task as done
        updateData = {
          status: 'DONE',
          completedAt: new Date(),
          output: output || existingTask.output,
        };
        logAction = 'completed';
        logDetails = output || '';
        break;

      case 'review':
        // Move to review
        updateData = {
          status: 'REVIEW',
          output: output || existingTask.output,
        };
        logAction = 'moved_to_review';
        logDetails = output || '';
        break;

      case 'block':
        // Report blocker
        updateData = {
          notes: `⚠️ BLOCKED: ${notes || existingTask.notes}`,
        };
        logAction = 'blocked';
        logDetails = notes || '';
        break;

      default:
        // Generic update
        updateData = {
          ...(notes !== undefined && { notes }),
          ...(output !== undefined && { output }),
          ...(status !== undefined && { status }),
        };
    }

    // Update task
    const task = await db.task.update({
      where: { id },
      data: updateData,
      include: { agent: true, project: true },
    });

    // Log activity
    await db.activityLog.create({
      data: {
        action: logAction,
        taskId: task.id,
        agentId: agent.id,
        projectId: agent.projectId,
        details: logDetails,
      },
    });

    // Update agent last seen
    await db.agent.update({
      where: { id: agent.id },
      data: { lastSeen: new Date(), isActive: true },
    });

    return NextResponse.json({
      success: true,
      task,
      action: logAction,
    });
  } catch (error) {
    console.error('Error updating task:', error);
    return NextResponse.json({ error: 'Failed to update task' }, { status: 500 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const apiKey = searchParams.get('api_key') || request.headers.get('X-Agent-Key');

    if (!apiKey) {
      return NextResponse.json({ error: 'Missing API key' }, { status: 401 });
    }

    const agent = await db.agent.findUnique({ where: { apiKey } });
    if (!agent) {
      return NextResponse.json({ error: 'Invalid API key' }, { status: 401 });
    }

    const task = await db.task.findUnique({ where: { id } });
    if (!task) {
      return NextResponse.json({ error: 'Task not found' }, { status: 404 });
    }

    if (task.projectId !== agent.projectId) {
      return NextResponse.json({ error: 'Task not in your project' }, { status: 403 });
    }

    // Unassign task from agent
    const updatedTask = await db.task.update({
      where: { id },
      data: { agentId: null },
    });

    // Log activity
    await db.activityLog.create({
      data: {
        action: 'unassigned',
        taskId: task.id,
        agentId: agent.id,
        projectId: agent.projectId,
        details: `Unassigned by ${agent.name}`,
      },
    });

    return NextResponse.json({ success: true, task: updatedTask });
  } catch (error) {
    console.error('Error unassigning task:', error);
    return NextResponse.json({ error: 'Failed to unassign task' }, { status: 500 });
  }
}
