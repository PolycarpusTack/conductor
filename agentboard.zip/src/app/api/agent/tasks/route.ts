import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * Agent HTTP API - Get tasks for an agent
 * 
 * Query params:
 * - api_key: Agent API key (required)
 * - status: Filter by status (optional: BACKLOG, IN_PROGRESS, REVIEW, DONE)
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const apiKey = searchParams.get('api_key');
    const status = searchParams.get('status');

    if (!apiKey) {
      return NextResponse.json({ 
        error: 'Missing api_key parameter',
        hint: 'Provide your agent API key as ?api_key=xxx'
      }, { status: 401 });
    }

    // Find agent by API key
    const agent = await db.agent.findUnique({
      where: { apiKey },
      include: { project: true },
    });

    if (!agent) {
      return NextResponse.json({ 
        error: 'Invalid API key',
        hint: 'Check your agent API key in the AgentBoard UI'
      }, { status: 401 });
    }

    // Update agent last seen
    await db.agent.update({
      where: { id: agent.id },
      data: { lastSeen: new Date(), isActive: true },
    });

    // Build where clause
    const where: { agentId: string | null; status?: string; projectId: string } = {
      projectId: agent.projectId,
      agentId: agent.id,
    };

    if (status) {
      where.status = status;
    }

    const tasks = await db.task.findMany({
      where,
      include: { project: { select: { name: true, color: true } } },
      orderBy: [
        { priority: 'desc' },
        { order: 'asc' },
      ],
    });

    return NextResponse.json({
      agent: {
        id: agent.id,
        name: agent.name,
        emoji: agent.emoji,
      },
      project: {
        id: agent.project.id,
        name: agent.project.name,
      },
      tasks,
      count: tasks.length,
    });
  } catch (error) {
    console.error('Error fetching agent tasks:', error);
    return NextResponse.json({ error: 'Failed to fetch tasks' }, { status: 500 });
  }
}
