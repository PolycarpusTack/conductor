import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * Activity Log API
 * 
 * GET /api/activity?projectId=xxx&limit=50
 * Returns recent activity for a project
 */

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('projectId');
    const limit = parseInt(searchParams.get('limit') || '50');
    const agentId = searchParams.get('agentId');

    if (!projectId) {
      return NextResponse.json({ error: 'Missing projectId parameter' }, { status: 400 });
    }

    const where: { projectId: string; agentId?: string } = { projectId };
    if (agentId) {
      where.agentId = agentId;
    }

    const activities = await db.activityLog.findMany({
      where,
      include: {
        agent: { select: { name: true, emoji: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    return NextResponse.json(activities);
  } catch (error) {
    console.error('Error fetching activities:', error);
    return NextResponse.json({ error: 'Failed to fetch activities' }, { status: 500 });
  }
}
