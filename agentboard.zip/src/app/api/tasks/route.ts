import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('projectId');
    
    const where = projectId ? { projectId } : {};
    
    const tasks = await db.task.findMany({
      where,
      include: {
        agent: true,
        project: true,
      },
      orderBy: [
        { status: 'asc' },
        { order: 'asc' },
      ],
    });
    
    return NextResponse.json(tasks);
  } catch (error) {
    console.error('Error fetching tasks:', error);
    return NextResponse.json({ error: 'Failed to fetch tasks' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { title, description, status, priority, tag, projectId, agentId, notes } = body;
    
    // Get the max order for the status column
    const maxOrderTask = await db.task.findFirst({
      where: { projectId, status: status || 'BACKLOG' },
      orderBy: { order: 'desc' },
    });
    
    const order = (maxOrderTask?.order || 0) + 1;
    
    const task = await db.task.create({
      data: {
        title,
        description,
        status: status || 'BACKLOG',
        priority: priority || 'MEDIUM',
        tag,
        projectId,
        agentId,
        notes,
        order,
      },
      include: {
        agent: true,
        project: true,
      },
    });
    
    return NextResponse.json(task);
  } catch (error) {
    console.error('Error creating task:', error);
    return NextResponse.json({ error: 'Failed to create task' }, { status: 500 });
  }
}
