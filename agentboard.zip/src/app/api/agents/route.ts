import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('projectId');
    
    const where = projectId ? { projectId } : {};
    
    const agents = await db.agent.findMany({
      where,
      include: {
        project: true,
        tasks: true,
      },
      orderBy: { createdAt: 'asc' },
    });
    
    return NextResponse.json(agents);
  } catch (error) {
    console.error('Error fetching agents:', error);
    return NextResponse.json({ error: 'Failed to fetch agents' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, emoji, color, description, projectId } = body;
    
    const agent = await db.agent.create({
      data: {
        name,
        emoji: emoji || '🤖',
        color: color || '#3b82f6',
        description,
        projectId,
      },
      include: {
        project: true,
      },
    });
    
    return NextResponse.json(agent);
  } catch (error) {
    console.error('Error creating agent:', error);
    return NextResponse.json({ error: 'Failed to create agent' }, { status: 500 });
  }
}
