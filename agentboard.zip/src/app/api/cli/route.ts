import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * CLI-style API for agents
 * 
 * Simple text-based responses for easy parsing by shell scripts and CLI tools.
 * 
 * GET /api/cli?api_key=xxx
 * - Returns next available task
 * 
 * POST /api/cli
 * - Body: { api_key, action, task_id?, notes?, output? }
 * - Actions: start, done, note, claim
 */

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const apiKey = searchParams.get('api_key');

    if (!apiKey) {
      return new Response('ERROR: Missing api_key\nUsage: /api/cli?api_key=YOUR_KEY', { status: 401 });
    }

    const agent = await db.agent.findUnique({
      where: { apiKey },
      include: { project: true },
    });

    if (!agent) {
      return new Response('ERROR: Invalid API key', { status: 401 });
    }

    // Update agent last seen
    await db.agent.update({
      where: { id: agent.id },
      data: { lastSeen: new Date(), isActive: true },
    });

    // Find next task
    const task = await db.task.findFirst({
      where: {
        projectId: agent.projectId,
        status: { in: ['BACKLOG', 'IN_PROGRESS'] },
        OR: [
          { agentId: agent.id },
          { agentId: null },
        ],
      },
      orderBy: [
        { status: 'desc' }, // IN_PROGRESS first
        { priority: 'desc' },
        { order: 'asc' },
      ],
    });

    if (!task) {
      return new Response('NO_TASKS: No tasks available\n');
    }

    const statusIcon = task.status === 'IN_PROGRESS' ? '🔄' : '📋';
    const priorityIcon = { URGENT: '🔴', HIGH: '🟠', MEDIUM: '🟡', LOW: '⚪' }[task.priority];

    return new Response(
      `TASK_ID: ${task.id}\n` +
      `STATUS: ${task.status}\n` +
      `PRIORITY: ${task.priority}\n` +
      `TITLE: ${task.title}\n` +
      `${task.description ? `DESCRIPTION: ${task.description}\n` : ''}` +
      `${task.notes ? `NOTES: ${task.notes}\n` : ''}` +
      `\n${statusIcon} ${priorityIcon} ${task.title}\n`
    );
  } catch (error) {
    console.error('CLI error:', error);
    return new Response('ERROR: Internal server error', { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { api_key, action, task_id, notes, output } = body;

    if (!api_key) {
      return new Response('ERROR: Missing api_key', { status: 401 });
    }

    const agent = await db.agent.findUnique({
      where: { apiKey: api_key },
      include: { project: true },
    });

    if (!agent) {
      return new Response('ERROR: Invalid API key', { status: 401 });
    }

    // Update agent last seen
    await db.agent.update({
      where: { id: agent.id },
      data: { lastSeen: new Date(), isActive: true },
    });

    switch (action) {
      case 'claim': {
        if (!task_id) {
          return new Response('ERROR: Missing task_id\nUsage: { action: "claim", task_id: "xxx" }', { status: 400 });
        }

        const task = await db.task.findUnique({ where: { id: task_id } });
        if (!task || task.projectId !== agent.projectId) {
          return new Response('ERROR: Task not found', { status: 404 });
        }

        if (task.agentId && task.agentId !== agent.id) {
          return new Response('ERROR: Task already claimed by another agent', { status: 409 });
        }

        const updatedTask = await db.task.update({
          where: { id: task_id },
          data: {
            agentId: agent.id,
            status: 'IN_PROGRESS',
            startedAt: new Date(),
          },
        });

        await db.activityLog.create({
          data: {
            action: 'claimed',
            taskId: task_id,
            agentId: agent.id,
            projectId: agent.projectId,
            details: `Claimed via CLI`,
          },
        });

        return new Response(`OK: Claimed task "${updatedTask.title}"\nTASK_ID: ${task_id}\n`);
      }

      case 'start': {
        if (!task_id) {
          return new Response('ERROR: Missing task_id', { status: 400 });
        }

        const task = await db.task.findUnique({ where: { id: task_id } });
        if (!task || task.projectId !== agent.projectId) {
          return new Response('ERROR: Task not found', { status: 404 });
        }

        if (task.agentId && task.agentId !== agent.id) {
          return new Response('ERROR: Task assigned to another agent', { status: 403 });
        }

        const updatedTask = await db.task.update({
          where: { id: task_id },
          data: {
            agentId: agent.id,
            status: 'IN_PROGRESS',
            startedAt: new Date(),
          },
        });

        await db.activityLog.create({
          data: {
            action: 'started',
            taskId: task_id,
            agentId: agent.id,
            projectId: agent.projectId,
            details: 'Started via CLI',
          },
        });

        return new Response(`OK: Started task "${updatedTask.title}"\n`);
      }

      case 'done': {
        if (!task_id) {
          return new Response('ERROR: Missing task_id', { status: 400 });
        }

        const task = await db.task.findUnique({ where: { id: task_id } });
        if (!task || task.projectId !== agent.projectId) {
          return new Response('ERROR: Task not found', { status: 404 });
        }

        const updatedTask = await db.task.update({
          where: { id: task_id },
          data: {
            status: 'DONE',
            completedAt: new Date(),
            output: output || null,
          },
        });

        await db.activityLog.create({
          data: {
            action: 'completed',
            taskId: task_id,
            agentId: agent.id,
            projectId: agent.projectId,
            details: output || 'Completed via CLI',
          },
        });

        return new Response(`OK: Completed task "${updatedTask.title}"\n`);
      }

      case 'note': {
        if (!task_id || !notes) {
          return new Response('ERROR: Missing task_id or notes', { status: 400 });
        }

        const task = await db.task.findUnique({ where: { id: task_id } });
        if (!task || task.projectId !== agent.projectId) {
          return new Response('ERROR: Task not found', { status: 404 });
        }

        await db.task.update({
          where: { id: task_id },
          data: { notes },
        });

        await db.activityLog.create({
          data: {
            action: 'progress',
            taskId: task_id,
            agentId: agent.id,
            projectId: agent.projectId,
            details: notes,
          },
        });

        return new Response(`OK: Updated notes for task "${task.title}"\n`);
      }

      case 'review': {
        if (!task_id) {
          return new Response('ERROR: Missing task_id', { status: 400 });
        }

        const task = await db.task.findUnique({ where: { id: task_id } });
        if (!task || task.projectId !== agent.projectId) {
          return new Response('ERROR: Task not found', { status: 404 });
        }

        await db.task.update({
          where: { id: task_id },
          data: {
            status: 'REVIEW',
            output: output || null,
          },
        });

        await db.activityLog.create({
          data: {
            action: 'moved_to_review',
            taskId: task_id,
            agentId: agent.id,
            projectId: agent.projectId,
            details: output || 'Moved to review via CLI',
          },
        });

        return new Response(`OK: Task "${task.title}" moved to review\n`);
      }

      default:
        return new Response(
          'ERROR: Unknown action\n' +
          'Available actions: claim, start, done, note, review\n' +
          'Example: { api_key: "xxx", action: "claim", task_id: "abc123" }',
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('CLI error:', error);
    return new Response('ERROR: Internal server error', { status: 500 });
  }
}
